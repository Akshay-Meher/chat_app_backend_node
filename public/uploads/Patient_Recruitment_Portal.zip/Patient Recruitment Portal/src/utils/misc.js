/**
 * Removes duplicates from an array
 * @param {Array} array - The array to remove duplicates from
 * @returns {Array} - The array with duplicates removed
 * @example uniqueArray([1, 2, 3, 3, 4, 5, 5, 6]) // Returns [1, 2, 3, 4, 5, 6] 
 */
export function uniqueArray(array) {
    return array.reduce((accumulator, currentValue) => {
        if (!accumulator.includes(currentValue)) {
            accumulator.push(currentValue);
        }
        return accumulator;
    }, [])
}

/**
 * Removes falsy values from an array
 * @param {Array} array - The array to remove falsy values from
 * @returns {Array} - The array with falsy values removed
 * @example removeFalsyValuesFromArray([0, 1, false, true, "", "hello", null, undefined, NaN]) // Returns [1, true, "hello"]
 */
export function removeFalsyValuesFromArray(array) {
    return array.filter(Boolean);
}

/**
 * Removes duplicate objects from an array based on a given key
 * @param {Array} array - The array of objects to remove duplicates from
 * @param {string} key - The key to check for duplicates
 * @returns {Array} - The array with duplicate objects removed
 * @example removeDuplicatesByKey([{id: 1}, {id: 2}, {id: 1}], 'id') // Returns [{id: 1}, {id: 2}]
 */
export function removeDuplicatesByKey(array, key) {
    const seen = new Set();
    return array.filter(item => {
        const keyValue = item[key];
        if (seen.has(keyValue)) {
            return false;
        } else {
            seen.add(keyValue);
            return true;
        }
    });
}

/**
 * Checks if an object is empty
 * @param {Object} obj - The object to check
 * @returns {boolean} - Whether the object is empty
 * @example isObjectEmpty({}) // Returns true
 */
export function isObjectNotEmpty(obj) {
    return Object.keys(obj).length > 0;
}