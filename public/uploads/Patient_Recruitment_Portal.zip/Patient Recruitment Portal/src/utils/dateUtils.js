/* eslint-disable eqeqeq */
import moment from "moment";

/**
 * Formats a date string from one format to another
 * @param {string} date - The date string to format
 * @param {string} currentFormat - The current format of the date string
 * @param {string} desiredFormat - The desired format of the date string
 * @returns {string} - The formatted date string
 * @example formatDateString("2021-01-01", "YYYY-MM-DD", "MM/DD/YYYY") // Returns "01/01/2021"
 */
export function formatDateString(date, currentFormat, desiredFormat) {
    if (!date) return moment(new Date()).format(desiredFormat);
    
    try {
      // Parse the date using the current format
      const parsedDate = moment(date, currentFormat, true);
      
      // Check if the parsed date is valid
      if (!parsedDate.isValid()) {
        return moment(new Date()).format(desiredFormat);
      }
  
      // Return the date in the desired format
      return parsedDate.format(desiredFormat);
    } catch (error) {
      return moment(new Date()).format(desiredFormat);
    }
}

/**
 * Formats a date string to a specific format
 * @param {string} date - The date string to format
 * @param {string} format - The desired format of the date string
 * @returns {string} - The formatted date string
 * @example formatDate("2021-01-01", "MM/DD/YYYY") // Returns "01/01/2021"
 */
export function parseDateTimeString(date, type) {
    if (type == 1) {
        // October 2, 2023 at 9:02 AM
        return moment(date).format("MMMM D, YYYY [at] h:mm A")
    }
    if (type == 2) {
        // October 2, 2023
        return moment(date).format("MMMM D, YYYY")
    }
    if (type == 3) {
        // Oct 2, 2023
        return moment(date).format("MMM D, YYYY")
    }
    if (type == 4) {
        // ... time ago
        return moment(date).fromNow()
    }
    if (type === 5) {
        // 2024-01-08
        return moment(date).format("YYYY-MM-DD");
    }
    if (type == 6) {
        // 01/08/2024
        return moment(date).format("MM/DD/YYYY");
    }
    if (type == 7) {
        // DEC 6, 2018 08:16 PM
        return moment(date).format("MMM D, YYYY hh:mm A");
    }
    if (type == 8) {
        // 01-08-2024
        return moment(date).format("MM-DD-YYYY");
    }
    if (type == 9) {
        // 07:28 am
        return moment(date, "HH:mm:ss").format("hh:mm A");
    }
    if (type == 10) {
        // Convert UTC Time to Local
        return moment.utc(date, "HH:mm:ss").local().format("hh:mm A");
    }
    if (type == 11) {
        // October 2, 2023 9:02 AM
        return moment(date).format("MMMM D, YYYY h:mm A")
    }
    if (type == 12) {
        // 01/08/2024 9:02 AM
        return moment(date).format("MM/DD/YYYY h:mm A");
    }
    if (type == 13) {
        return moment(date, "HH:mm:ss").format("hh:mm A");
    }
    if (type == 14) {
        // OCT 2, 2023
        return moment(date).format("MMM D, YYYY").toUpperCase()
    }
    if (type == 15) {
        // OCT 2, 2023 9:02 AM
        return moment(date).format("MMM D, YYYY hh:mm A").toUpperCase();
    }
    if (type == 16) {
        // Aug 2, 2024 at 5:43 PM GMT+5:30
        return moment(date).format("MMM D, YYYY [at] h:mm A [GMT]Z");
    }
    return date
}