export const INVALID_EMAIL = 'Please enter a valid email address.';
export const INVALID_PASSWORD = 'Password must be at least 8 characters long and contain at least one number and one special character.';
export const PASSWORD_NOT_MATCH = 'Your password and confirm password do not match';
export const INVALID_MOBILE = 'Mobile Number must be 10 digits';

export function requiredMessage(fieldName) {
    return fieldName ? `${fieldName} is required.` : 'Required field.';
}

export function atLeastCharacters(fieldName, length) {
    return `${fieldName} must be at least ${length} character${length > 1 ? 's' : ''}.`;
}

export function mustContain(fieldName, text) {
    return `${fieldName} must contain ${text}.`;
}