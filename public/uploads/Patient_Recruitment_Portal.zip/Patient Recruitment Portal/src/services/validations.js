import * as Yup from "yup";
import {
  atLeastCharacters,
  INVALID_EMAIL,
  INVALID_MOBILE,
  INVALID_PASSWORD,
  mustContain,
  PASSWORD_NOT_MATCH,
  requiredMessage,
} from "../utils";

// common validation regex pattern----------------------------------------------------------------
export const passwordRegex =
  /(?=.*\d)(?=.*[A-Z])(?=.*[!@#$%^&*()+=-?;,./{}|":<>[\]\\' ~_]).{8,}/;
export const nameRegex = /^[a-zA-Z]+$/;
export const mobileRegex = /^\d{10}$/;
export const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w\w+)+$/;
export const zipRegex = /^\d{6}(-\d{4})?$/;

// common validation rules----------------------------------------------------------------
export const phone_numberValidation = Yup.string()
  .required(requiredMessage("Phone Number"))
  .matches(mobileRegex, INVALID_MOBILE);

export const emailValidation = Yup.string()
  .email(INVALID_EMAIL)
  .matches(emailRegex, INVALID_EMAIL)
  .required(requiredMessage("Email"));

export const passwordValidation = Yup.string()
  .required(requiredMessage("Password"))
  .matches(passwordRegex, INVALID_PASSWORD);

export const confirmPasswordValidation = Yup.string()
  .oneOf([Yup.ref("password"), null], PASSWORD_NOT_MATCH)
  .required(requiredMessage("Confirm Password"));

export const registrationSchema = Yup.object({
  firstName: Yup.string()
    .required(requiredMessage("First Name"))
    .matches(nameRegex, mustContain("First Name", "only alphabets")),
  lastName: Yup.string()
    .required(requiredMessage("Last Name"))
    .matches(nameRegex, mustContain("Last Name", "only alphabets")),
  phoneNumber: phone_numberValidation,
  email: emailValidation,
  password: passwordValidation,
  confirmPassword: confirmPasswordValidation,
  address: Yup.string().required(requiredMessage("Address")),
  city: Yup.string()
    .required(requiredMessage("City"))
    .matches(nameRegex, mustContain("City", "only alphabets and spaces")),
  state: Yup.string()
    .required(requiredMessage("State"))
    .matches(nameRegex, mustContain("State", "only alphabets and spaces")),
  zipCode: Yup.string()
    .required(requiredMessage("ZIP Code"))
    .matches(zipRegex, "Invalid ZIP Code"),
  country: Yup.string().required(requiredMessage("country")),
});

export const loginSchema = Yup.object({
  email: emailValidation,
  password: passwordValidation,
});
