import axiosInstance from "./AxiosInstance";

export const registerApiUrl = '/register';
export const loginApiUrl = '/login';


export function registerRequest(data) {
    return axiosInstance.post(registerApiUrl, data);
}

export function loginRequest(data) {
    return axiosInstance.post(loginApiUrl, data);
}